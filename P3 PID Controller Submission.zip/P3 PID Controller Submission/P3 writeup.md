# P3 writeup


This project is to implement a PID controller on the simulator.

## Reflection:
* Student describes the effect of the P, I, D component of the PID algorithm in their implementation. Is it what you expected?
Well, after finishing the TODOs, I applied P control first, but the car swang heavily, just like drunk driving...
Then I applied PD control by tuning parameters over and over, the car ran along the lap normally. 
When I added Integrate term to the controller, the car can also ran along the lap, similar to what PD control performed.
(*I want to record the videos, but  I don’t know how to do it.*)

* Student discusses how they chose the final hyperparameters (P, I, D coefficients). This could be have been done through manual tuning, twiddle, SGD, or something else, or a combination!
The parameters were tuned manually, firstly I tuned the P coefficient, when it performed well, I added D coefficient to the controller, then I coefficient... And all the performance can be shown by running the codes submitted.

